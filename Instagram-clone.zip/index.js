const express = require('express');
const mongoose = require('mongoose');

const app = express();

const {MONGOURL} = require('./key')
require("./model/model.js")
require("./model/postmodel.js")
app.use(express.json())
app.use(require('./routes/route'))
app.use(require('./routes/postroute'))
mongoose.connect(MONGOURL)
mongoose.connection.on("connected",()=>console.log("successfully connected"))
mongoose.connection.on("disconnected",()=>console.log("not connected"))
app.listen(5000, ()=> console.log('listening on port 5000'))