const express = require("express");
const mongoose = require("mongoose");
const router = express.Router();
const Post = mongoose.model("post");
const requiredlogin = require("../middleware/requiredlogin");

router.post("/createpost", (req, res) => {
  const { title, body, image } = req.body;
  console.log(title, body, image);

  if (!title || !body || !image) {
    return res.status(422).json({ error: "Please fill all details" });
  }

  const post = new Post({
    title,
    body,
    postedBy: req.user,
    photo: image,
  });
  post
    .save()
    .then((result) => {
      res.json({ post: result, message: "created successfully" });
    })
    .catch((err) => {
      console.log(err);
    });
}) |
  router.get("/allpost", requiredlogin, (req, res) => {
    Post.find()
      .populate("PostedBy", "username")
      .then((users) => {
        res.json({ post: users });
      });
  });

router.get("/mypost", requiredlogin, (req, res) => {
  Post.find({ PostedBy: req.user._id }).then((post) => {
    res.json({ post:post });
  });
});

module.exports = router;
