const express = require("express");
const jwt = require("jsonwebtoken")
const bcrypt = require("bcrypt");
const {SECRETKEY} = require('../key')
const router = express.Router();
const requiredlogin=require("../middleware/requiredlogin")
const mongoose = require("mongoose");
const UserDetails = mongoose.model("UserDetails");

router.get("/userdetails", requiredlogin, (req,res)=>{
    res.send("hello user details")
})
router.post("/Signup", (req, res) => {
  const { email, username, password } = req.body;
 //console.log(req.body)
  if ((!email, !username, !password)) {
    res.status(422).json({ error: "Please fill in all the details" });
  }
  UserDetails.findOne({ email: email }).then((savedata) => {
    if (savedata) {
      return res.status(422).json({ error: "user already exist" });
    }
    bcrypt.hash(password,12).then(incrptedPassword => {
        const User=new UserDetails({
            email,
            username,
            password:incrptedPassword
        })
        User.save().then(user=>{
            res.json({message: "data saved successfully"})
        }).catch(err => console.log(err))
    })
    
  });
});

router.post("/signin",(req,res)=>{
    const{email,password} = req.body
   
    if(!email || !password){
        res.status(422).send('user not found')
    }
    UserDetails.findOne({email: email}).then(user =>{
        console.log(user)
        if(!user){
           return res.status(422).json({error: "incorrect email or password"})
        }
        bcrypt.compare(password,user.password).then(match=>{
            if(match){
               const {_id,email,username} = user
               
                //res.json({message:"successfully loged in"})
                const token = jwt.sign({_id:user._id},SECRETKEY)
                res.json({token:token, message: "successfuly loged in", user: {_id,email,username}})
            }else{
                return res.status(422).json({error:"in valid email or password"})
            }
        })
    })
})
module.exports = router;

