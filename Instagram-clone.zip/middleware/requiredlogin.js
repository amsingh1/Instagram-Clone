const jwt = require("jsonwebtoken")
const mongoose= require("mongoose")
const{ SECRETKEY} = require("../key")
const UserDetails = mongoose.model("UserDetails")

module.exports = (req,res,next)=>{
    const {authorization} =  req.headers
    console.log(authorization)
    if (!authorization){
        res.status(401).json({error: "you must be logged in"})
    }
    const token=authorization.replace("Bearer ", "")

    jwt.verify(token,SECRETKEY, (err, payload) =>{
        if(err){
            return res.status(401).json({error: "you must be logged in"})
        }
        const {_id}= payload
        UserDetails.findById(_id).then(userdata=>{
            req.user=userdata
            next()
        })

    })
}