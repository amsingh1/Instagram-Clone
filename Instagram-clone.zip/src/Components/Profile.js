import React from 'react'
import photo from "./photo.jpg"

export default function Profile() {

  const[data,setdata]=useState([])

  fetch("/mypost", {
    method: "GET",
    headers: {
      "Content-Type": "application/json",
      "Authorization": "Bearer " + localStorage.getItem("token")}
    }).then(data => data.json()).then(data=> 
      setdata(data.post))
  return (



    <div className="profileheader">
      
        <div> 

<img src={photo} alt=""  style={{hight: '200px', width: '200px', borderRadius:"150px"}}/>
        </div>
        <div className='profiletitle'>

            <h3> Amit Singh</h3>
            <div className='profiledetails' >
            <p className='mx-5'>40 post </p>
            <p>100 followers </p>
            <p className='mx-5'>100 following </p>

            </div>


            
        </div>


    </div>
  )
}
