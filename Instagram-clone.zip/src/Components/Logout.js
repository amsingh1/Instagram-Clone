import React,{useContext} from 'react'
import { MyContext } from "../App";
import { useNavigate } from "react-router-dom"

function Logout() {
    const navigate = useNavigate()
    const {state,dispatch} = useContext(MyContext);

  const logOut= ()=>{

      localStorage.clear()
    dispatch({ type: "Clear"})

    navigate("/signup")

  }
  return (
    <div>

{logOut()}


    </div>
  )
}

export default Logout