import React, { useState } from "react";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import { Link } from "react-router-dom";

export default function Signup() {
  const [form, setForm] = useState({ username:"", email:"", password:"" });

  const handleInput = (e) => {
    const { name, value } = e.target;
    setForm((prev) => {
      return {
        ...prev,
        [name]: value,
      };
    });
  };

  function handleSubmit(e) {
    e.preventDefault();

    fetch("/Signup",{
      method: "POST",
      headers: {
        "Content-Type":"application/json",
      },
      body: JSON.stringify({
        username: form.username,
        password: form.password,
        email: form.email,
      }),
    })
      .then((data) => data.json())
      .then((data1) => {
        // {data1={error:"pls fill all the details"}}
        if (data1.error) {
          toast.error(data1.error, {
            theme: "dark",
          });
        } else {
          toast.success(data1.message, {
            theme: "dark",
          });
        }
      });
  }

  return (
    <div className="signupcontainer">
      <div className="form">
        <div class="input-group flex-nowrap">
          <span class="input-group-text" id="addon-wrapping">
            @
          </span>
          <input
            type="text"
            class="form-control"
            name="username"
            value={form.username}
            onChange={handleInput}
            placeholder="Username"
            aria-label="Username"
            aria-describedby="addon-wrapping"
          />
        </div>
        <div class="input-group flex-nowrap">
          <span class="input-group-text" id="addon-wrapping">
            @
          </span>
          <input
            type="email"
            class="form-control"
            name="email"
            value={form.email}
            onChange={handleInput}
            placeholder="email"
            aria-label="Username"
            aria-describedby="addon-wrapping"
          />
        </div>

        <div class="input-group flex-nowrap">
          <span class="input-group-text" id="addon-wrapping">
            @
          </span>
          <input
            type="password"
            class="form-control"
            name="password"
            value={form.password}
            onChange={handleInput}
            placeholder="password"
            aria-label="Username"
            aria-describedby="addon-wrapping"
          />
        </div>

        <button type="button" class="btn btn-primary" onClick={handleSubmit}>
          Primary
        </button>
        <h5>
          <Link to="/signin">Already have an account? </Link>
        </h5>
        <ToastContainer />
        <p>{form.username}</p>
      </div>
    </div>
  );
}
