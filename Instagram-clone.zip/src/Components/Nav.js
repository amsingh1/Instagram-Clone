import React,{useContext} from 'react'
import {Link} from "react-router-dom"
import {MyContext} from "../App"
export default function Nav() {

  const {state, dispatch} = useContext(MyContext)

  function Prelog(){
    if(!state){
      return(
        [<li className="nav-item">
        <Link className="nav-link active" aria-current="page" to="/Signup">Sign up</Link>
      </li>,
      <li className="nav-item">
        <Link className="nav-link active" aria-current="page" to="/signin">Sign in</Link>
      </li>]
      )
    
    } else{
      return(
        [
          <li className="nav-item">
          <Link className="nav-link active" aria-current="page" to="/profile">Profile</Link>
        </li>,
        <li className="nav-item">
          <Link className="nav-link active" aria-current="page" to="/create">Create post</Link>
        </li>,
         <li className="nav-item">
         <Link className="nav-link active" aria-current="page" to="/logout">Log out</Link>
       </li>

        ]

      )
    
    }
    
    

  }
  return (
    <div>
        <nav className="navbar navbar-expand-lg navbar-light bg-light">
  <div className="container-fluid">
    <Link to={state ? "/profile": "/signup"} className="navbar-brand">Instgram</Link>
    <button className="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span className="navbar-toggler-icon"></span>
    </button>
    <div className="collapse navbar-collapse" id="navbarSupportedContent">
      
      <ul className="navbar-nav me-auto mb-2 mb-lg-0">
  
           {Prelog()}
        
        </ul>
      
    </div>
  </div>
</nav>
    </div>
  )
}
