import React,{useState,useEffect} from 'react'
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
export default function CreatePost() {

  const[form, setForm]=useState({ title:'', body:''})
  const[image,setImage] = useState("")

 const [url, setUrl] = useState("")

 useEffect(()=>{
   
if(url){
  
  fetch("/createpost", {
    method: "POST",
    headers:{
      "Content-Type": "application/json"
    },
    body:JSON.stringify({
      title:form.title,
      body:form.body,
      image:url
    })
  }).then(data=>data.json()).then(data1=>{ 
    if (data1.error) {
      toast.error(data1.error, {
        theme: "dark",
      });
    } else {
      console.log(data1.message);
      toast.success(data1.message);
    
    }})

}
 }, [url])

 

  const handleInput=(e)=>{
      const{ name,value} = e.target 
      setForm((prev)=>{
          return {
           ...prev,[name]:value
          }
      })  
  }
 const handleSubmit=()=>{
   console.log("first")
  const data = new FormData();
  data.append("file", image)
  data.append("upload_preset", "instagram")
 data.append("cloud_name", "amsingh")
 fetch("https://api.cloudinary.com/v1_1/amsingh/image/upload",

 {
   method:"post",
   body:data,
 })
 .then(data=>data.json())
 .then(data=> setUrl(data.url))
 
 }
  return (
    <div className= "signupcontainer">
      <div>  

<div class="input-group flex-nowrap">
  <span class="input-group-text" id="addon-wrapping">@</span>
  <input type="text" class="form-control"  name="title" value={form.title} onChange={handleInput} placeholder="title"  aria-describedby="addon-wrapping"/>
</div>

<div class="input-group flex-nowrap">
  <span class="input-group-text" id="addon-wrapping">@</span>
  <input type="text" class="form-control" name="body" value={form.body} onChange={handleInput} placeholder="body"  aria-describedby="addon-wrapping"/>
</div>

  
  <input type="file" id="myfile" name="myfile" onChange={(e)=>setImage(e.target.files[0])}/>


<button class="btn btn-primary" onClick={handleSubmit}>Submit</button>
</div>
< ToastContainer/>
    </div>
  )
}
