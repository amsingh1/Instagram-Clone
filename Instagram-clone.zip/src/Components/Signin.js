import React,{useState,useContext}  from 'react'
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import {useNavigate} from "react-router-dom"
import { MyContext } from '../App';

export default function Signin() {
const {state, dispatch} = useContext(MyContext)
    const[form, setForm]=useState({ email:'', password:'',})
    const navigate = useNavigate()
    const handleInput=(e)=>{
        const{ name,value} = e.target 
        setForm((prev)=>{
            return {
             ...prev,[name]:value
            }
        })  
    }

    const handleSubmit = ()=>{
      
      fetch("/signin",{
        method: "POST",
        headers: {
          "Content-Type":"application/json",
        },
        body: JSON.stringify({
        
          email: form.email,
          password: form.password
        }),
      })
        .then((data) => data.json())
        .then((data1) => {
          // {data1={error:"pls fill all the details"}}
          console.log(data1)
          if (data1.error) {
            toast.error(data1.error, {
              theme: "dark",
            });
          } else {
            console.log(data1.message);
            localStorage.setItem("token", data1.token)
            localStorage.setItem("user", JSON.stringify(data1.user))
            dispatch({type:"User",payload: data1.user})
            toast.success(data1.message);
            navigate("/create")

          }
        });
    }
    

  return (
    <div className="signupcontainer"> 

    <div className='form'>
   
    
<div class="input-group flex-nowrap">
  <span class="input-group-text" id="addon-wrapping">@</span>
  <input type="text" class="form-control"  name="email" value={form.email} onChange={handleInput} placeholder="email" aria-label="Username" aria-describedby="addon-wrapping"/>
</div>

<div class="input-group flex-nowrap">
  <span class="input-group-text" id="addon-wrapping">@</span>
  <input type="text" class="form-control" name="password" value={form.password} onChange={handleInput} placeholder="password" aria-label="Username" aria-describedby="addon-wrapping"/>
</div>

<button style={{marginTop: '10px'}} className="btn btn-primary" onClick={handleSubmit}>Submit</button>
    

<p>{form.username}</p>

    </div>
    <ToastContainer/>
    </div>
  )
}
