import React, { createContext, useReducer, useEffect ,useContext} from "react";
import "./App.css";
import Nav from "./Components/Nav";
import Signup from "./Components/Signup";
import Signin from "./Components/Signin";
import Profile from "./Components/Profile";
import CreatePost from "./Components/CreatePost";
import Logout from "./Components/Logout";

import { Routes, Route,useNavigate } from "react-router-dom";
import { istate, reducer } from "./reducer/userReducer";

export const MyContext = createContext();

function Navigation() {
  const {state,dispatch} = useContext(MyContext);
   const navigate = useNavigate()
   useEffect( ()=>{
     const user= JSON.parse(localStorage.getItem('user'));
    if(user)
     {dispatch({type:"User", payload:user})}
     else{
       navigate("/signup")
     }
   },
   [] ) 
   
  
  return (
    <Routes>
      <Route path={"/Signup"} element={<Signup />}></Route>
      <Route path={"/signin"} element={<Signin />}></Route>
      <Route path="/profile" element={<Profile />}></Route>
      <Route path="/create" element={<CreatePost />}></Route>
      <Route path="/logout" element={<Logout />}></Route>
      
    </Routes>
  );
}

function App() {
  const [state, dispatch] = useReducer(reducer, istate);
console.log(state)
  return (
    <MyContext.Provider value={{state,dispatch}}>
      <div className="App">
        <Nav />

        <Navigation />
      </div>
    </MyContext.Provider>
  );
}

export default App;
